from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='dashboard'),
    path('ferramentas/', views.ferramentas_lista, name='ferramentas_lista'),
    path('ferramentas/criar/', views.ferramentas_criar, name='ferramentas_criar'),
    path('ferramentas/<int:id>/editar/', views.ferramentas_editar, name='ferramentas_editar'),
    path('ferramentas/<int:id>/deletar/', views.ferramentas_deletar, name='ferramentas_deletar'),
    path('movimentacoes/', views.movimentacoes_lista, name='movimentacoes_lista'),
    path('movimentacoes/criar/', views.movimentacoes_criar, name='movimentacoes_criar'),
    path('alertas/', views.alertas_lista, name='alertas_lista'),
    path('alertas/<int:id>/toggle/', views.toggle_alerta, name='toggle_alerta'),
]

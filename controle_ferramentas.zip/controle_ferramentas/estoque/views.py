from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.views.decorators.csrf import csrf_exempt
from django.db import models
import json
from .models import Ferramenta, Movimentacao, Alerta

def dashboard(request):
    ferramentas = Ferramenta.objects.all()
    total = ferramentas.count()
    estoque_baixo = ferramentas.filter(quantidade_estoque__lte=models.F('nivel_minimo')).count()
    sem_estoque = ferramentas.filter(quantidade_estoque=0).count()
    
    context = {
        'total_ferramentas': total,
        'estoque_baixo': estoque_baixo,
        'sem_estoque': sem_estoque,
    }
    return render(request, 'estoque/dashboard.html', context)

def ferramentas_lista(request):
    ferramentas = Ferramenta.objects.all()
    return render(request, 'estoque/ferramentas.html', {'ferramentas': ferramentas})

def ferramentas_criar(request):
    if request.method == 'POST':
        ferramenta = Ferramenta(
            marca=request.POST.get('marca'),
            modelo=request.POST.get('modelo'),
            material=request.POST.get('material'),
            tamanho=request.POST.get('tamanho'),
            peso=request.POST.get('peso'),
            tensao_eletrica=request.POST.get('tensao_eletrica'),
            descricao=request.POST.get('descricao'),
            quantidade_estoque=int(request.POST.get('quantidade_estoque', 0)),
            nivel_minimo=int(request.POST.get('nivel_minimo', 1)),
        )
        ferramenta.save()
        return redirect('ferramentas_lista')
    return render(request, 'estoque/ferramenta_form.html')

def ferramentas_editar(request, id):
    ferramenta = get_object_or_404(Ferramenta, id=id)
    if request.method == 'POST':
        ferramenta.marca = request.POST.get('marca')
        ferramenta.modelo = request.POST.get('modelo')
        ferramenta.material = request.POST.get('material')
        ferramenta.tamanho = request.POST.get('tamanho')
        ferramenta.peso = request.POST.get('peso')
        ferramenta.tensao_eletrica = request.POST.get('tensao_eletrica')
        ferramenta.descricao = request.POST.get('descricao')
        ferramenta.quantidade_estoque = int(request.POST.get('quantidade_estoque', 0))
        ferramenta.nivel_minimo = int(request.POST.get('nivel_minimo', 1))
        ferramenta.save()
        return redirect('ferramentas_lista')
    return render(request, 'estoque/ferramenta_form.html', {'ferramenta': ferramenta})

def ferramentas_deletar(request, id):
    ferramenta = get_object_or_404(Ferramenta, id=id)
    if request.method == 'POST':
        ferramenta.delete()
        return redirect('ferramentas_lista')
    return render(request, 'estoque/ferramenta_confirm_delete.html', {'ferramenta': ferramenta})

def movimentacoes_lista(request):
    movimentacoes = Movimentacao.objects.all()
    return render(request, 'estoque/movimentacoes.html', {'movimentacoes': movimentacoes})

def movimentacoes_criar(request):
    ferramentas = Ferramenta.objects.all()
    if request.method == 'POST':
        ferramenta = get_object_or_404(Ferramenta, id=request.POST.get('ferramenta_id'))
        tipo = request.POST.get('tipo')
        quantidade = int(request.POST.get('quantidade'))
        
        if tipo == 'saida' and ferramenta.quantidade_estoque < quantidade:
            return render(request, 'estoque/movimentacao_form.html', {
                'ferramentas': ferramentas,
                'erro': 'Quantidade insuficiente em estoque'
            })
        
        if tipo == 'entrada':
            ferramenta.quantidade_estoque += quantidade
        else:
            ferramenta.quantidade_estoque -= quantidade
        
        ferramenta.save()
        
        movimentacao = Movimentacao(
            ferramenta=ferramenta,
            tipo=tipo,
            quantidade=quantidade,
            motivo=request.POST.get('motivo'),
        )
        movimentacao.save()
        
        return redirect('movimentacoes_lista')
    
    return render(request, 'estoque/movimentacao_form.html', {'ferramentas': ferramentas})

def alertas_lista(request):
    ferramentas = Ferramenta.objects.all()
    sem_estoque = ferramentas.filter(quantidade_estoque=0)
    estoque_baixo = ferramentas.filter(
        quantidade_estoque__gt=0,
        quantidade_estoque__lte=models.F('nivel_minimo')
    )
    estoque_ok = ferramentas.filter(quantidade_estoque__gt=models.F('nivel_minimo'))
    
    context = {
        'sem_estoque': sem_estoque,
        'estoque_baixo': estoque_baixo,
        'estoque_ok': estoque_ok,
    }
    return render(request, 'estoque/alertas.html', context)

@csrf_exempt
@require_http_methods(["POST"])
def toggle_alerta(request, id):
    ferramenta = get_object_or_404(Ferramenta, id=id)
    ferramenta.alerta_ativo = not ferramenta.alerta_ativo
    ferramenta.save()
    return JsonResponse({'sucesso': True, 'ativo': ferramenta.alerta_ativo})

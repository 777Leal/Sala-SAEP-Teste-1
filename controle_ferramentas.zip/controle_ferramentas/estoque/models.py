from django.db import models
from django.utils import timezone

class Ferramenta(models.Model):
    marca = models.CharField(max_length=100)
    modelo = models.CharField(max_length=100)
    material = models.CharField(max_length=100, blank=True, null=True)
    tamanho = models.CharField(max_length=50, blank=True, null=True)
    peso = models.CharField(max_length=50, blank=True, null=True)
    tensao_eletrica = models.CharField(max_length=50, blank=True, null=True)
    descricao = models.TextField(blank=True, null=True)
    quantidade_estoque = models.IntegerField(default=0)
    nivel_minimo = models.IntegerField(default=1)
    alerta_ativo = models.BooleanField(default=True)
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['marca', 'modelo']

    def __str__(self):
        return f"{self.marca} {self.modelo}"

    def status_estoque(self):
        if self.quantidade_estoque == 0:
            return 'sem_estoque'
        elif self.quantidade_estoque <= self.nivel_minimo:
            return 'estoque_baixo'
        else:
            return 'ok'


class Movimentacao(models.Model):
    TIPO_CHOICES = [
        ('entrada', 'Entrada'),
        ('saida', 'Saída'),
    ]

    ferramenta = models.ForeignKey(Ferramenta, on_delete=models.CASCADE, related_name='movimentacoes')
    tipo = models.CharField(max_length=10, choices=TIPO_CHOICES)
    quantidade = models.IntegerField()
    motivo = models.CharField(max_length=255, blank=True, null=True)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-criado_em']

    def __str__(self):
        return f"{self.ferramenta} - {self.tipo} ({self.quantidade})"


class Alerta(models.Model):
    TIPO_CHOICES = [
        ('estoque_baixo', 'Estoque Baixo'),
        ('fora_de_estoque', 'Fora de Estoque'),
    ]

    ferramenta = models.ForeignKey(Ferramenta, on_delete=models.CASCADE, related_name='alertas')
    tipo = models.CharField(max_length=20, choices=TIPO_CHOICES)
    ativo = models.BooleanField(default=True)
    criado_em = models.DateTimeField(auto_now_add=True)
    atualizado_em = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-criado_em']

    def __str__(self):
        return f"{self.ferramenta} - {self.tipo}"

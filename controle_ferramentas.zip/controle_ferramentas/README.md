# Controle de Estoque de Ferramentas

Sistema web para gerenciamento de estoque de ferramentas e equipamentos manuais desenvolvido com Django.

## Funcionalidades

- Cadastro de ferramentas com características específicas (marca, modelo, material, tamanho, peso, tensão elétrica)
- Rastreamento de quantidade em estoque
- Movimentações de entrada e saída
- Sistema de alertas configurável por produto
- Histórico completo de movimentações
- Dashboard com resumo de estoque

## Tecnologias

- Django 5.2.8
- Python 3.11
- SQLite (banco de dados)
- HTML5, CSS3, JavaScript puro

## Como Executar

### Passo 1: Abrir o terminal na pasta do projeto

```bash
cd /caminho/para/controle_ferramentas
```

### Passo 2: Ativar o ambiente virtual

**No Linux/Mac:**
```bash
source venv/bin/activate
```

**No Windows:**
```bash
venv\Scripts\activate
```

### Passo 3: Instalar as dependências

```bash
pip install -r requirements.txt
```

### Passo 4: Executar o servidor

```bash
python manage.py runserver
```

### Passo 5: Acessar a aplicação

Abra seu navegador e acesse: **http://localhost:8000**

## Estrutura do Projeto

```
controle_ferramentas/
├── config/              # Configurações do Django
├── estoque/             # Aplicação principal
│   ├── models.py        # Modelos de dados
│   ├── views.py         # Lógica das páginas
│   ├── urls.py          # Rotas da aplicação
│   ├── templates/       # Arquivos HTML
│   └── static/          # CSS e JavaScript
├── manage.py            # Gerenciador do Django
├── requirements.txt     # Dependências Python
└── db.sqlite3           # Banco de dados (criado automaticamente)
```

## Funcionalidades Principais

### Dashboard
- Visualização rápida do total de ferramentas
- Alertas de estoque baixo e sem estoque
- Acesso rápido às principais funções

### Ferramentas
- Criar, editar e deletar ferramentas
- Registrar características específicas
- Visualizar status de estoque

### Movimentações
- Registrar entradas e saídas
- Histórico completo de movimentações
- Motivo de cada movimentação

### Alertas
- Monitorar ferramentas com estoque crítico
- Ativar/desativar alertas por ferramenta
- Visualização por status (sem estoque, estoque baixo, normal)

## Notas

- O banco de dados SQLite é criado automaticamente na primeira execução
- Não é necessário criar um superusuário para usar a aplicação
- Os dados são salvos automaticamente no arquivo `db.sqlite3`
